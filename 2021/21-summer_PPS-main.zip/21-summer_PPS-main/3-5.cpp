#include <iostream>
using namespace std;



int forecast(day, N);

//recursive로 해보자
// 0 좋은날    1 싫은날
int main() {
    int N;
    bool day;
    cin>>N>>day;
    double percent[4];
    cin>>percent[0]>>percent[1]>>percent[2]>>percent[3];

    int count=0;

    cout<<forecast(day,N, count)
}


int forecast(day, N,count){
    count++;
    if(count==N){
        if(day)
    }
    if()



}


