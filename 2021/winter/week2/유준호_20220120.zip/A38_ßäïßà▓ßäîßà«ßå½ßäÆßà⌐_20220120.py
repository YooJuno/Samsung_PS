import math
class Solution(object):
    def mySqrt(self, x):
        answer = int(math.sqrt(x)) 
        return answer


        