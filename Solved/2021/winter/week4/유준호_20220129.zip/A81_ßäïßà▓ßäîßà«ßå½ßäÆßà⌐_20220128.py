x = int(input())
for i in range(x):
    nums = list(map(int, input().split()))
    nums.sort()
    print(nums[-3])