N, M = input().split()

N = int(N)
M = int(M)

print( ((N-1)+(M-1)*N) )