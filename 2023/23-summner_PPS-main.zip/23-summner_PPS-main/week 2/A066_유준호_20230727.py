num = input()
num = sorted(num, reverse=True)
print(''.join(num))