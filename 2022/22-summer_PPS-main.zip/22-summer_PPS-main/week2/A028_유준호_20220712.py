A, B = input().split()
A = int(A)
B = int(B)

print(A+B)