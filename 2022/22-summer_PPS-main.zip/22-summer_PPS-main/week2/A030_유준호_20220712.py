N = int(input())
feel = int(input())

list = input().split()
print(list)